module.exports = function(){

	//console.log("Initialized / loaded api.js module");

	return {
		print: function(){
			console.log("Hi from api.js");
		},

		hi: function(){
			console.log("HI from second function");
		}
	};

};