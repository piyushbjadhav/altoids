
var api = require('./api.js');	// set up links to functions, modulues.

//api();							// actual function call;

var p = api();						// construct an instance / object of module 			

p.print();							// function calls.
p.hi();